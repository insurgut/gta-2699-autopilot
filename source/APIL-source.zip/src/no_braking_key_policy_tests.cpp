#include "no_braking_key_policy.hpp"
#include <cassert>
int main(){
  for(int direction=-1;direction<=1;direction+=2){
    for(std::size_t key=0;key<5;++key){
      assert(!blockAutopilotBrakingKey(false,direction,key,true));
      assert(!blockAutopilotBrakingKey(true,direction,key,false));
      assert(blockAutopilotBrakingKey(true,direction,key,true)==
             (key==4||key==(direction<0?0u:1u)));
    }
  }
  assert(blockAutopilotBrakingKey(true,1,1,true));   // S brake
  assert(blockAutopilotBrakingKey(true,1,4,true));   // Space brake
  assert(!blockAutopilotBrakingKey(true,1,0,true));  // W gas
  assert(!blockAutopilotBrakingKey(true,-1,1,true)); // S reverse gas
  assert(blockAutopilotBrakingKey(true,-1,0,true));  // W reverse brake
  assert(!blockAutopilotBrakingKey(true,-1,4,false)); // Space key-up
}
