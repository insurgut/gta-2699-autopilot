#pragma once
inline constexpr char apilVersion[]="0.2.06";
inline constexpr wchar_t apilVersionWide[]=L"0.2.06";
