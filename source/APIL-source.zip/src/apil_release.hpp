#pragma once
inline constexpr char apilVersion[]="0.2.11";
inline constexpr wchar_t apilVersionWide[]=L"0.2.11";
