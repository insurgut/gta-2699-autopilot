#include "route_catalog.hpp"
#include "route_selection.hpp"
#include "route_sections.hpp"
#include "stops.hpp"
#include <cassert>
#include <filesystem>
int main(){
  std::vector<Point> r{{0,0,0,30},{10,0,0,30},{20,0,0,0},{30,0,0,30}};
  for(auto& p:r)p.followRecordedSpeed=true;
  r[1].noRecordedBraking=true;
  assert(routeSpeedAheadCap(r,0,{1,0,0,0},30)>=29.99f);
  r[1].noRecordedBraking=false;
  assert(routeSpeedAheadCap(r,0,{1,0,0,0},30)<20);
  r[1].noRecordedBraking=true;
  r[2].speedLimit=8;
  assert(routeSpeedAheadCap(r,0,{1,0,0,0},30)<25);
  r[2].speedLimit=0;
  RoutePick at{0,.5f,0,0,0,true};
  Point anchor=routeAnchor(r,at);
  assert(anchor.noRecordedBraking&&anchor.followRecordedSpeed);
  auto continuation=continueRoute(r,at,false);
  assert(continuation.size()==4&&continuation.front().noRecordedBraking);
  auto dir=std::filesystem::temp_directory_path()/"apil-0.2.12-section-clear-test";
  std::filesystem::remove_all(dir);
  RouteCatalog catalog;catalog.open(dir);
  auto saved=r;saved[1].speedLimit=12;saved[1].ignoreObstacles=true;saved[1].waitMs=2200;
  assert(catalog.add(saved,"Test"));
  assert(catalog.entries[0].points[1].noRecordedBraking);
  assert(catalog.clearSectionSettings(0,0,0));
  const auto& cleared=catalog.entries[0].points[1];
  assert(cleared.speedLimit==0&&!cleared.ignoreObstacles&&!cleared.noRecordedBraking);
  assert(cleared.waitMs==2200);
  assert(!catalog.clearSectionSettings(0,2,3));
  RouteCatalog reopened;reopened.open(dir);
  assert(reopened.entries.size()==1);
  assert(!reopened.entries[0].points[1].noRecordedBraking);
  assert(reopened.entries[0].points[1].waitMs==2200);
  std::filesystem::remove_all(dir);
}
