#pragma once
#include <cstddef>
// The five virtual driving keys are indexed W=0, S=1, A=2, D=3, Space=4.
// This policy applies only to APIL-generated key-downs. Key-ups must ALWAYS
// pass through to avoid sticking a brake after switching sections.
// On reverse sections S is the accelerator, so W becomes the brake key.
inline bool blockAutopilotBrakingKey(bool markedSection,int direction,
                                    std::size_t key,bool down) noexcept {
    if(!markedSection||!down)return false;
    return key==4||(direction<0?key==0:key==1);
}
