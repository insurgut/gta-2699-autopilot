#pragma once
#include "route.hpp"
#include "endpoint_settings.hpp"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <vector>

// A short connector to the actual recorded start is permitted ONLY when looping,
// ignored-tail is enabled and the delay is zero. The ordinary brakes and all
// collision / object-wait rules remain active outside this specific handoff.
struct SeamlessLoopPath {
    std::vector<Point> points;
    size_t seam=SIZE_MAX; // last point of current lap; following points are preview of next lap
};
inline float seamlessPolylineMeters(const std::vector<Point>&points){
    float total=0;
    for(size_t i=1;i<points.size();++i) total+=distance(points[i-1],points[i]);
    return total;
}
inline SeamlessLoopPath makeSeamlessLoopPath(
    const std::vector<Point>&current,const std::vector<Point>&canonical,
    unsigned ignoreSeconds,unsigned pauseSeconds,bool repeat,bool reverse){
    SeamlessLoopPath result{current,SIZE_MAX};
    if(!repeat||!ignoreSeconds||pauseSeconds||reverse||current.size()<12||canonical.size()<12)return result;
    if(current.size()>100000||canonical.size()>100000)return result;
    if(seamlessPolylineMeters(canonical)<40.0f)return result;
    if(distance(current.back(),canonical.front())>15.0f)return result;
    if(std::fabs(current.back().z-canonical.front().z)>2.5f)return result;
    if(current.back().direction!=1||canonical.front().direction!=1||canonical[1].direction!=1)return result;
    // Avoid a severe instant reversal at the lap joint.
    const Point&prev=current[current.size()-2];
    const Point&last=current.back();
    const Point&first=canonical.front();
    const Point&next=canonical[1];
    const float ax=last.x-prev.x,ay=last.y-prev.y,bx=next.x-first.x,by=next.y-first.y;
    const float an=std::hypot(ax,ay),bn=std::hypot(bx,by);
    if(an>0.1f&&bn>0.1f&&(ax*bx+ay*by)/(an*bn)<-0.25f)return result;
    result.seam=result.points.size()-1;
    // Append a look-ahead tail. The steering/speed controller otherwise brakes
    // for its final waypoint even though this is actually a lap boundary.
    float preview=0;
    Point prior=current.back();
    unsigned appended=0;
    for(int cycle=0;cycle<20 && preview<900.0f && appended<14000;++cycle){
        for(size_t i=0;i<canonical.size() && preview<900.0f && appended<14000;++i){
            Point p=canonical[i];
            // Virtual preview must never generate fake Enter presses or timed stops.
            p.waitMs=0;p.enterCount=0;
            if(cycle==0 && i==0 && distance(prior,p)<0.05f)continue;
            preview+=distance(prior,p);
            result.points.push_back(p);
            prior=p;
            ++appended;
        }
    }
    if(preview<90.0f){
        result.points=current;
        result.seam=SIZE_MAX;
    }
    return result;
}
inline bool seamlessLoopMayWrap(const SeamlessLoopPath&lap,size_t segment,Point car){
    if(lap.seam==SIZE_MAX||lap.points.size()<lap.seam+3||segment<lap.seam)return false;
    if(distance(car,lap.points[lap.seam+1])>24.0f)return false;
    return segment>=lap.seam+2 || distance(car,lap.points[lap.seam+1])<=5.0f;
}
inline size_t seamlessResumeSegment(size_t segment,size_t seam){
    if(segment<=seam+1)return 0;
    return segment-seam-1;
}
