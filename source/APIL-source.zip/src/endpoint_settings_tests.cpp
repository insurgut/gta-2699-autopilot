#include "endpoint_settings.hpp"
#include <cassert>
int main(){
    Point a{0,0,0,10},b{100,0,0,10},c{200,0,0,10};
    const std::vector<Point> r{a,b,c};
    assert(trimEndpointTail(r,0).size()==3);
    const auto cut=trimEndpointTail(r,5);
    assert(cut.size()==3 && std::abs(cut.back().x-150)<.001);
    assert(trimEndpointTail(r,60).size()==2);
    assert(validEndpointSettings({60,300}));
    assert(!validEndpointSettings({61,0}));
}
