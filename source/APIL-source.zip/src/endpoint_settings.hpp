#pragma once
#include "route.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

// Route-local options stored in a small sidecar file, leaving GTA_AUTOPILOT v8 compatible.
struct EndpointSettings {
    unsigned ignoreFinalSeconds=0;
    unsigned restartDelaySeconds=0;
};
inline bool validEndpointSettings(const EndpointSettings& s){
    return s.ignoreFinalSeconds<=60 && s.restartDelaySeconds<=300;
}
// Route recordings only store positions and speeds, not an exact timestamp for each point.
// Estimate the ignored tail by distance / recorded speed, retaining at least two points.
// The original route is never destructively rewritten by this operation.
inline std::vector<Point> trimEndpointTail(const std::vector<Point>& source,unsigned ignoreSeconds){
    auto route=source;
    if(ignoreSeconds==0 || route.size()<3)return route;
    double remaining=double(std::min(ignoreSeconds,60u));
    for(size_t i=route.size()-1;i>1;--i){
        const Point a=route[i-1],b=route[i];
        const double meters=distance(a,b);
        const double velocity=std::clamp((double(a.speed)+double(b.speed))*.5,1.5,90.0);
        const double secs=meters/velocity;
        if(!std::isfinite(secs)||secs<=.0001){route.resize(i);continue;}
        if(remaining>=secs){
            remaining-=secs;
            route.resize(i);
            continue;
        }
        const float t=float(std::clamp(1.0-remaining/secs,0.0,1.0));
        Point end=a;
        end.x=a.x+(b.x-a.x)*t;
        end.y=a.y+(b.y-a.y)*t;
        end.z=a.z+(b.z-a.z)*t;
        end.speed=a.speed+(b.speed-a.speed)*t;
        end.facingX=a.facingX+(b.facingX-a.facingX)*t;
        end.facingY=a.facingY+(b.facingY-a.facingY)*t;
        end.waitMs=0;end.enterCount=0;
        route[i]=end;
        route.resize(i+1);
        return route;
    }
    return route;
}
