#include "route.hpp"
#include "route_sections.hpp"
#include "stops.hpp"
#include <cassert>
#include <filesystem>
#include <vector>
int main(){
 std::vector<Point> r{{0,0,0,10},{10,0,0,0},{20,0,0,10}};
 for(auto& p:r)p.followRecordedSpeed=true;
 r[1].waitMs=2000;
 assert(nextStop(r,1)==1&&routeSpeedAt(r[0],r[1],1,20)<2);
 r[1].noRecordedBraking=true;
 assert(nextStop(r,1)==SIZE_MAX&&routeSpeedAt(r[0],r[1],1,20)==20);
 auto tmp=std::filesystem::temp_directory_path()/"apil-no-brake-test.txt";
 assert(writeRoute(tmp,r));
 RouteInputs in;std::vector<Point> back;
 assert(loadRoute(tmp,back,&in));std::filesystem::remove(tmp);
 assert(back[1].noRecordedBraking&&back[1].waitMs==2000);
 assert(in.pace==RecordedPace::Unavailable);
 back[1].noRecordedBraking=false;
 assert(nextStop(back,1)==1);
}
