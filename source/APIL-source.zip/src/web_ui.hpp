#pragma once
#include <windows.h>
#include <objbase.h>
#include <shlwapi.h>
#include <atomic>
#include <functional>
#include <memory>
#include <string>
#include <filesystem>
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunknown-pragmas"
#pragma GCC diagnostic ignored "-Wattributes"
#include "../third_party/webview2/WebView2.h"
#pragma GCC diagnostic pop
#include "webview_guids.hpp"
#include "archive_map.hpp"

template<class Interface,class...Args> class WebHandler final:public Interface {
    std::atomic<ULONG> refs{1};GUID iid;std::function<HRESULT(Args...)> callback;
public:
    WebHandler(GUID id,std::function<HRESULT(Args...)> fn):iid(id),callback(std::move(fn)){}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void**out)override{if(!out)return E_POINTER;*out=nullptr;if(IsEqualIID(id,IID_IUnknown)||IsEqualIID(id,iid)){*out=static_cast<Interface*>(this);AddRef();return S_OK;}return E_NOINTERFACE;}
    ULONG STDMETHODCALLTYPE AddRef()override{return ++refs;}
    ULONG STDMETHODCALLTYPE Release()override{ULONG n=--refs;if(!n)delete this;return n;}
    HRESULT STDMETHODCALLTYPE Invoke(Args...args)override{return callback(args...);}
};
class WebUI {
    struct State {
        HWND parent=nullptr;bool alive=true,ready=false,mapCache=false;uint64_t started=0;std::wstring trusted,trustedPath;std::filesystem::path mapFolder;
        ICoreWebView2Controller*controller=nullptr;ICoreWebView2*web=nullptr;
        std::function<void(const std::wstring&)> command;std::function<void()> onReady;std::function<void(HRESULT)> onError;
        EventRegistrationToken receiveToken{},navigationToken{},windowToken{},completedToken{};
        bool trusts(LPCWSTR uri)const{if(!uri)return false;wchar_t path[32768]{};DWORD length=32768;if(FAILED(PathCreateFromUrlW(uri,path,&length,0)))return false;return _wcsicmp(path,trustedPath.c_str())==0;}
        void dispose(){if(web){web->remove_WebMessageReceived(receiveToken);web->remove_NavigationStarting(navigationToken);web->remove_NewWindowRequested(windowToken);web->remove_NavigationCompleted(completedToken);}if(controller){controller->Close();controller->Release();controller=nullptr;}if(web){web->Release();web=nullptr;}}
        void fail(HRESULT hr){if(!alive)return;ready=false;if(controller)controller->put_IsVisible(FALSE);if(onError)onError(hr);}
        ~State(){dispose();}
    };
    std::shared_ptr<State> state=std::make_shared<State>();
public:
    bool mapCacheAvailable()const{return state->mapCache;}
    bool active()const{return state->ready;}
    void close(){state->alive=false;state->ready=false;state->dispose();}
    void resize(){if(state->controller){RECT r{};GetClientRect(state->parent,&r);state->controller->put_Bounds(r);}}
    void send(const std::wstring&json){if(state->alive&&state->ready&&state->web)state->web->PostWebMessageAsJson(json.c_str());}
    bool start(HWND parent,const std::filesystem::path&app,const std::filesystem::path&data,std::function<void(const std::wstring&)> command,std::function<void()> onReady,std::function<void(HRESULT)> onError){
        auto s=state;s->parent=parent;s->command=std::move(command);s->onReady=std::move(onReady);s->onError=std::move(onError);s->started=GetTickCount64();s->mapFolder=data/archiveCacheFolder;
        auto page=app.parent_path()/L"ui"/L"index.html";if(!std::filesystem::exists(page))return false;
        wchar_t url[32768]{};DWORD length=32768;if(FAILED(UrlCreateFromPathW(page.c_str(),url,&length,0)))return false;s->trusted=url;s->trustedPath=page.wstring();
        auto loader=LoadLibraryExW((app/L"WebView2Loader.dll").c_str(),nullptr,LOAD_WITH_ALTERED_SEARCH_PATH);if(!loader)return false;
        using Create=HRESULT(STDAPICALLTYPE*)(PCWSTR,PCWSTR,ICoreWebView2EnvironmentOptions*,ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*);
        auto create=reinterpret_cast<Create>(GetProcAddress(loader,"CreateCoreWebView2EnvironmentWithOptions"));if(!create)return false;
        auto envHandler=new WebHandler<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler,HRESULT,ICoreWebView2Environment*>(wvIID_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler,[s](HRESULT result,ICoreWebView2Environment*env){
            if(!s->alive)return S_OK;
            if(FAILED(result)||!env){s->fail(result);return S_OK;}
            auto controllerHandler=new WebHandler<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler,HRESULT,ICoreWebView2Controller*>(wvIID_ICoreWebView2CreateCoreWebView2ControllerCompletedHandler,[s](HRESULT status,ICoreWebView2Controller*controller){
                if(!s->alive)return S_OK;
                if(FAILED(status)||!controller){s->fail(status);return S_OK;}
                s->controller=controller;controller->AddRef();if(FAILED(controller->get_CoreWebView2(&s->web))){s->fail(E_FAIL);return S_OK;}
                constexpr GUID core3={0xa0d6df20,0x3b92,0x416d,{0xaa,0x0c,0x43,0x7a,0x9c,0x72,0x78,0x57}};
                ICoreWebView2_3* resources=nullptr;
                if(SUCCEEDED(s->web->QueryInterface(core3,reinterpret_cast<void**>(&resources)))){
                    s->mapCache=SUCCEEDED(resources->SetVirtualHostNameToFolderMapping(L"district-map.invalid",
                        s->mapFolder.c_str(),COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_DENY_CORS));
                    resources->Release();
                }
                ICoreWebView2Controller2*color=nullptr;if(SUCCEEDED(controller->QueryInterface(wvIID_ICoreWebView2Controller2,reinterpret_cast<void**>(&color)))){color->put_DefaultBackgroundColor({255,43,43,43});color->Release();}
                ICoreWebView2Settings*settings=nullptr;if(SUCCEEDED(s->web->get_Settings(&settings))){settings->put_AreDevToolsEnabled(FALSE);settings->put_AreDefaultContextMenusEnabled(FALSE);settings->put_IsStatusBarEnabled(FALSE);settings->put_IsZoomControlEnabled(FALSE);settings->Release();}
                auto receive=new WebHandler<ICoreWebView2WebMessageReceivedEventHandler,ICoreWebView2*,ICoreWebView2WebMessageReceivedEventArgs*>(wvIID_ICoreWebView2WebMessageReceivedEventHandler,[s](ICoreWebView2*,ICoreWebView2WebMessageReceivedEventArgs*args){
                    if(!s->alive)return S_OK;
                    LPWSTR source=nullptr,text=nullptr;args->get_Source(&source);
                    if(s->trusts(source)&&SUCCEEDED(args->TryGetWebMessageAsString(&text))&&text&&wcslen(text)<=512){if(wcscmp(text,L"ready")==0&&!s->ready){s->ready=true;if(s->controller)s->controller->put_IsVisible(TRUE);s->onReady();}s->command(text);}
                    if(source)CoTaskMemFree(source);
                    if(text)CoTaskMemFree(text);
                    return S_OK;
                });s->web->add_WebMessageReceived(receive,&s->receiveToken);receive->Release();
                auto navigation=new WebHandler<ICoreWebView2NavigationStartingEventHandler,ICoreWebView2*,ICoreWebView2NavigationStartingEventArgs*>(wvIID_ICoreWebView2NavigationStartingEventHandler,[s](ICoreWebView2*,ICoreWebView2NavigationStartingEventArgs*args){LPWSTR uri=nullptr;args->get_Uri(&uri);if(!s->trusts(uri))args->put_Cancel(TRUE);if(uri)CoTaskMemFree(uri);return S_OK;});s->web->add_NavigationStarting(navigation,&s->navigationToken);navigation->Release();
                auto newWindow=new WebHandler<ICoreWebView2NewWindowRequestedEventHandler,ICoreWebView2*,ICoreWebView2NewWindowRequestedEventArgs*>(wvIID_ICoreWebView2NewWindowRequestedEventHandler,[](ICoreWebView2*,ICoreWebView2NewWindowRequestedEventArgs*args){args->put_Handled(TRUE);return S_OK;});s->web->add_NewWindowRequested(newWindow,&s->windowToken);newWindow->Release();
                auto completed=new WebHandler<ICoreWebView2NavigationCompletedEventHandler,ICoreWebView2*,ICoreWebView2NavigationCompletedEventArgs*>(wvIID_ICoreWebView2NavigationCompletedEventHandler,[s](ICoreWebView2*,ICoreWebView2NavigationCompletedEventArgs*args){BOOL success=FALSE;args->get_IsSuccess(&success);if(!success)s->fail(E_FAIL);return S_OK;});s->web->add_NavigationCompleted(completed,&s->completedToken);completed->Release();
                RECT r{};GetClientRect(s->parent,&r);controller->put_Bounds(r);controller->put_IsVisible(FALSE);if(FAILED(s->web->Navigate(s->trusted.c_str())))s->fail(E_FAIL);return S_OK;
            });env->CreateCoreWebView2Controller(s->parent,controllerHandler);controllerHandler->Release();return S_OK;
        });auto profile=data/L"interface";HRESULT hr=create(nullptr,profile.c_str(),nullptr,envHandler);envHandler->Release();return SUCCEEDED(hr);
    }
};
inline std::wstring jsonString(const std::wstring&text){std::wstring out=L"\"";for(wchar_t c:text){if(c==L'"'||c==L'\\'){out+=L'\\';out+=c;}else if(c<32){wchar_t raw[7]{};swprintf(raw,7,L"\\u%04x",unsigned(c));out+=raw;}else out+=c;}return out+L"\"";}
