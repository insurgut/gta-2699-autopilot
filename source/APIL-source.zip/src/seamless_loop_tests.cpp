#include "seamless_loop.hpp"
#include "driving.hpp"
#include <cassert>
#include <cmath>
#include <vector>
int main(){
    std::vector<Point> circle;
    for(int i=0;i<=120;++i){
        const float theta=6.28318530718f*i/120.0f;
        Point p{25*std::cos(theta),25*std::sin(theta),0,4};
        p.direction=1;circle.push_back(p);
    }
    const auto trimmed=trimEndpointTail(circle,2);
    assert(distance(trimmed.back(),trimmed.front())<15.0f);
    auto path=makeSeamlessLoopPath(trimmed,trimmed,2,0,true,false);
    assert(path.seam==trimmed.size()-1);
    assert(path.points.size()>trimmed.size());
    assert(seamlessPolylineMeters(path.points)>900);
    assert(!seamlessLoopMayWrap(path,0,trimmed.front()));
    assert(seamlessLoopMayWrap(path,path.seam,trimmed.front()));
    assert(seamlessLoopMayWrap(path,path.seam+2,trimmed[1]));
    assert(seamlessResumeSegment(path.seam+3,path.seam)==2);
    assert(makeSeamlessLoopPath(trimmed,trimmed,2,3,true,false).seam==SIZE_MAX);
    assert(makeSeamlessLoopPath(trimmed,trimmed,0,0,true,false).seam==SIZE_MAX);
    assert(makeSeamlessLoopPath(trimmed,trimmed,2,0,false,false).seam==SIZE_MAX);
    assert(makeSeamlessLoopPath(trimmed,trimmed,2,0,true,true).seam==SIZE_MAX);
    auto far=trimmed;far.front().x+=300;
    assert(makeSeamlessLoopPath(trimmed,far,2,0,true,false).seam==SIZE_MAX);
    auto reverse=trimmed;reverse[0].direction=-1;
    assert(makeSeamlessLoopPath(trimmed,reverse,2,0,true,false).seam==SIZE_MAX);
    // The controller must no longer see the cut point as its final brake point.
    const auto pos=trimmed[trimmed.size()-3];
    auto out=driveOutput(path.points,path.seam-4,pos,
                         0.8f,-0.6f,7.0f,12.0f,SIZE_MAX,0,true);
    assert(!out.arrived);
    assert(out.targetSpeed>1.0f);
}
