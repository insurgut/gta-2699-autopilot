#pragma once
#include "apil_runtime.hpp"

inline bool webViewRuntimeInstalled(){
    constexpr wchar_t key[]=L"Software\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
    for(HKEY hive:{HKEY_CURRENT_USER,HKEY_LOCAL_MACHINE}){
        const DWORD flags=RRF_RT_REG_SZ|(hive==HKEY_LOCAL_MACHINE?RRF_SUBKEY_WOW6432KEY:0);
        wchar_t version[64]{};
        DWORD bytes=sizeof(version);
        if(RegGetValueW(hive,key,L"pv",flags,nullptr,version,&bytes)==ERROR_SUCCESS&&
           version[0]&&wcscmp(version,L"0.0.0.0")!=0)return true;
    }
    return false;
}

inline bool ensureWebViewRuntime(const std::filesystem::path& root){
    if(webViewRuntimeInstalled())return true;
    const auto setup=root/L"native"/L"MicrosoftEdgeWebview2Setup.exe";
    if(unpackApilResource(setup,109,false)){
        std::wstring command=L"\""+setup.wstring()+L"\" /silent /install";
        STARTUPINFOW startup{};
        startup.cb=sizeof(startup);
        PROCESS_INFORMATION process{};
        if(CreateProcessW(setup.c_str(),command.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&startup,&process)){
            CloseHandle(process.hThread);
            WaitForSingleObject(process.hProcess,INFINITE);
            CloseHandle(process.hProcess);
            if(webViewRuntimeInstalled())return true;
        }
    }
    MessageBoxW(nullptr,L"Не удалось установить Microsoft Edge WebView2 Runtime. Проверь подключение к интернету и снова запусти APIL.",L"APIL",MB_OK|MB_ICONERROR);
    return false;
}
