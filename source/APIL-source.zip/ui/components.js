/* Adapted from ETS2LA.UI Razor components at v2026.11.5251. GPL-3.0.
   The component class strings and DOM structure are retained from the sources
   listed in third_party/ets2la/PROVENANCE.md. */
'use strict';
const Components = (() => {
  const escape = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icons = {
    play:'<path d="m8 5 11 7-11 7z"/>', record:'<circle cx="12" cy="12" r="7"/>', stop:'<rect x="6" y="6" width="12" height="12" rx="1"/>',
    link:'<path d="m10 13 4-4m-6 8-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0m2-1 1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/>',
    folder:'<path d="M3 7h7l2 3h9v10H3zM3 7V4h7l2 3h8v3"/>', save:'<path d="M5 3h12l4 4v14H3V3zM7 3v6h10V3M7 21v-8h10v8"/>',
    report:'<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 12h7m-7 4h7"/>', marker:'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0z"/><circle cx="12" cy="10" r="2"/>',
    trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
    home:'<path d="m3 11 9-8 9 8v9H3zM9 20v-6h6v6"/>',
    route:'<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h7a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h7"/>',
    settings:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="var(--bg)"/><circle cx="15" cy="12" r="2" fill="var(--bg)"/><circle cx="11" cy="18" r="2" fill="var(--bg)"/>',
    pulse:'<path d="M3 12h4l2-5 5 10 3-5h4"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8v.2"/>',
    keyboard:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 9h.1m5 0h.1m5 0h.1M7 13h.1m5 0h.1m5 0h.1M8 16h8"/>',
    gauge:'<path d="M4 16a8 8 0 1 1 16 0M12 13l4-4"/><circle cx="12" cy="13" r="1"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    error:'<path d="M12 3 2 20h20L12 3zm0 6v5m0 3v.1"/>',
    pause:'<path d="M9 5v14m6-14v14"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>'
  };
  const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.arrow}</svg>`;
  const card = (title, body, extra='') => `<div class="flex flex-col w-full gap-2 ${extra}"><div class="flex mx-4 justify-between items-center"><div class="flex flex-col gap-1"><p class="font-semibold description">${escape(title)}</p></div></div><div class="card flex flex-col w-full bg-control-bg-dark border p-4 gap-6 transition-all border-bg-darker rounded-sm">${body}</div></div>`;
  const button = (id, label, glyph, accent=false, extra='') => `<button class="button ${accent?'button-accent':''} ${extra}" data-command="${escape(id)}">${icon(glyph)}<span>${escape(label)}</span></button>`;
  const toggle = (id, title, description='') => `<button class="toggle-row flex justify-between w-full items-center hover:bg-control-bg-dark min-h-[32px] cursor-pointer" role="switch" aria-checked="false" data-toggle="${id}"><span class="toggle-label"><span>${escape(title)}</span>${description?`<span class="help-icon" title="${escape(description)}" aria-label="${escape(description)}">${icon('info')}</span>`:''}</span><span class="switch-track relative flex items-center justify-between px-[7px] w-[63px] h-[27px] bg-control rounded-lg text-[12px] font-medium"><span class="switch-on transition-opacity">ON</span><span class="switch-off transition-opacity">OFF</span><span class="switch-thumb absolute left-[3.5px] size-[21px] bg-text-l/80 rounded-md transition-transform duration-200"></span></span></button>`;
  const input = (id, title, description, value, attrs='') => `<label class="setting-input flex flex-col gap-2"><span class="flex flex-col"><span>${escape(title)}</span><span class="description">${escape(description)}</span></span><input id="${id}" value="${escape(value)}" class="w-full h-11 px-4 rounded-md bg-control-bg border border-control-bg focus:outline-none focus:ring-1 focus:ring-accent focus:ring-offset-1 focus:ring-offset-control" ${attrs}></label>`;
  const section = title => `<p class="section-title description flex items-center gap-2">${escape(title)}</p>`;
  return {escape,icon,card,button,toggle,input,section};
})();
