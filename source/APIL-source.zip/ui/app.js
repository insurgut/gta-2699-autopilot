'use strict';
(() => {
const {card,button,toggle,input,section,escape,icon}=Components;
let state={version:'0.2.05',updateStatus:'Проверка обновлений…',connected:false,connecting:false,gpsEnabled:true,gpsDriving:false,gpsStatus:'Внешнее чтение GPS ещё не подключено.',gpsSpeed:30,gpsWheelStep:5,gpsPreview:true,recording:false,playing:false,points:0,segment:0,speed:0,target:'30',laps:0,odometer:0,navigatorTarget:30,routeName:'Маршрут',mode:'Ожидание',message:'Подключи игру, затем запиши маршрут.',connection:'Войди в District и сядь за руль.',sceneStatus:'3D-обзор окружения',radar:true,overlay:true,scene:true,loop:false,horn:true,anticipatorySpeed:true,stableDetour:true,autoRecovery:true,trafficPrediction:true,flightRecording:true,cell:'1.25',radius:'20',panelWidth:360,panelHeight:480,panelOpacity:85,panelMap:false,panelMapOpacity:75,routeColor:'#FFFFFF',selectedRoute:'',finishIgnoreSeconds:0,finishPauseSeconds:0,routes:[],models:[],path:[],position:[0,0]};
let currentPage='settings', modelSignature='';
const send=message=>{if(window.chrome?.webview)window.chrome.webview.postMessage(message);};
const shortcuts=[
 ['Ins','Запись и сохранение'],['Del','Проезд со старта до 15 м / стоп'],['End','Продолжить с точки'],
 ['Enter','Добавить действие'],['Esc / P','Снять управление'],['Колесо','Скорость GPS'],
 ['ЛКМ','Выбрать участок'],['СКМ','Переместить карту'],['Колесо на карте','Масштаб'],['Home','Показать весь путь на карте']
].map(([key,label])=>`<div class="shortcut-row"><span>${label}</span><kbd>${key}</kbd></div>`).join('');
const keys=()=>card('Клавиши',`<div class="shortcut-grid">${shortcuts}</div>`);
const heading=(name,description)=>`<div class="page-heading"><div><h1>${name}</h1><p class="description">${description}</p></div></div>`;
document.getElementById('pages').innerHTML=`
<div class="page" data-panel="dashboard">
<div class="page-heading"><h1>Главная</h1></div>
${keys()}
<div class="dashboard-pair">
${card('Навигатор',`<div class="dashboard-nav" id="dashboard-nav">
  <div class="nav-metrics">
    <div class="nav-capsule nav-speed">${icon('gauge')}<div><strong id="speed">—</strong><small>км/ч</small></div></div>
    <div class="nav-capsule">${icon('target')}<span id="navigator-target"></span></div>
    <div class="nav-capsule"><span id="navigator-mode-icon">${icon('pause')}</span><span id="mode"></span></div>
  </div>
  <div class="dashboard-scene"><canvas id="navigator-canvas" width="240" height="174" aria-label="Трёхмерное окружение"></canvas><span id="navigator-placeholder">Сядь за руль</span></div>
  <div id="navigator-banner" class="navigator-banner" aria-live="polite"></div>
</div>`,'dashboard-nav-card')}
${card('Маршрут',`<div class="metrics dashboard-metrics">
  <div><span class="metric-value" data-text="points">0</span><span class="metric-label">точек</span></div>
  <div><span class="metric-value" id="odometer">0</span><span class="metric-label">пробег, км</span></div>
  <div><span class="metric-value" data-text="laps">0</span><span class="metric-label">кругов</span></div>
</div><div class="progress-track"><div class="progress-value" id="progress"></div></div><p class="description" id="route-summary"></p><p class="small-copy" id="message"></p>`)}
</div>
<div class="dashboard-pair">
${card('GPS по метке',`${toggle('gpsEnabled','Автопилот по метке')}<p class="small-copy" data-text="gpsStatus"></p><div class="inline-fields">${input('gpsSpeed','Скорость, км/ч','','30','type="number" min="5" max="300" step="1"')}${input('gpsWheelStep','Шаг колеса, км/ч','','5','type="number" min="1" max="30" step="1"')}</div>${toggle('gpsPreview','Полоса прогноза')}`)}
${card('Параметры проезда',`${input('target','Скорость записанного маршрута, км/ч','','30','inputmode="decimal" maxlength="12"')}${toggle('loop','Повторять маршрут по кругу')}`)}
</div></div>
<div class="page" data-panel="route">${heading('Маршруты','')}
${card('Сохранённые маршруты',`<div id="saved-routes" class="saved-routes"></div>`)}
${keys()}
${card('Карта',`<div class="route-map-flow"><canvas class="route-preview route-map" id="route-canvas" tabindex="0" aria-label="Карта маршрута"></canvas><fieldset class="section-editor" id="section-editor" disabled><legend id="section-title">Выбери участок маршрута</legend><div id="section-preview" class="mini-preview" hidden>
<svg viewBox="0 0 340 84" aria-hidden="true"><polyline id="section-preview-line"/><circle id="section-preview-start" r="4"/><circle id="section-preview-end" r="4"/></svg>
<div class="mini-tags"><span id="section-preview-distance"></span><span id="section-preview-speed"></span><span id="section-preview-obstacles"></span></div></div><div class="section-fields"><label>Первый отрезок<input type="number" id="section-from" min="1" step="1"></label><label>Последний отрезок<input type="number" id="section-to" min="1" step="1"></label><label>Скорость, км/ч<input type="number" id="section-speed" min="0" max="3600" step="1" placeholder="Разная"></label><label>Препятствия<select id="section-obstacles"><option value="0">Учитывать</option><option value="1">Игнорировать</option><option value="mixed" disabled>Разные настройки</option></select></label></div><div class="action-row"><button class="button button-primary" id="section-apply">${icon('save')} Сохранить</button><button class="button" id="section-reset">${icon('trash')} Сбросить</button></div><p id="section-feedback" class="small-copy" role="status"></p></fieldset><div class="stat-line"><span class="route-legend"><span></span> Записанный маршрут</span><span class="description" id="route-count"></span></div><div id="custom-sections" class="custom-sections"></div></div>`)}
</div>
<div class="page" data-panel="settings">${heading('Настройки','Только параметры нашего автопилота')}
<div class="action-row">${button('connect','Подключить','link',true)}</div>
<div class="tabs" role="tablist"><button class="tab active" role="tab" aria-selected="true" data-tab="driving">Проезд</button><button class="tab" role="tab" aria-selected="false" data-tab="display">Отображение</button><button class="tab" role="tab" aria-selected="false" data-tab="objects">Объекты</button></div>
<div class="settings-tab active" data-tab-panel="driving">${card('Помощь при проезде',`${toggle('radar','Проверять препятствия','Проверка свободного пути и построение объезда.')}${toggle('horn','Двойной гудок рядом с авто','Два коротких E при сближении до 10 м; повтор после выезда из зоны и паузы 10 секунд.')}${toggle('loop','Повторять маршрут по кругу')}`)}${card('Улучшения автопилота',`${toggle('anticipatorySpeed','Плавный разгон до заданной скорости','Плавно повышает целевую скорость при разгоне. Повороты сами по себе больше не снижают заданную скорость.')}${toggle('stableDetour','Сохранять объезд при краткой помехе','Удерживает выбранный путь до 1,4 секунды. При выключении заблокированный объезд пересчитывается сразу.')}${toggle('autoRecovery','Автоматически выезжать при застревании','Проверяет место сзади и пробует освободить машину. При выключении машина ждёт на ручнике.')}${toggle('trafficPrediction','Предсказывать движение автомобилей','Притормаживает перед встречной или догоняющей машиной, ждёт её проезда и продолжает путь. Работает и по GPS.')}${toggle('flightRecording','Записывать данные о сбоях','Сохраняет JSONL со сценой и действиями. При выключении прекращает запись и очищает буфер; готовые файлы сохраняются.')}`)}${card('Клавиши',shortcuts)}</div>
<div class="settings-tab" data-tab-panel="display">${card('В игре',`${toggle('overlay','Нить маршрута и радар')}${toggle('scene','3D-обзор окружения слева')}<p class="description">Нить отображается в пределах 70 м. Стартовые сетки отображаются независимо от режима, радара и переключателя нити.</p>`)}${card('Панель навигатора',`<div class="inline-fields">${input('panelWidth','Ширина, px','От 240 до 900','360','type="number" min="240" max="900" step="1"')}${input('panelHeight','Высота, px','От 160 до 800; до 300 скорость слева','480','type="number" min="160" max="800" step="1"')}</div>${input('panelOpacity','Непрозрачность подложки, %','0: прозрачная; 100: сплошная. Машины и текст остаются видимыми.','85','type="range" min="0" max="100" step="1"')}<div class="stat-line"><span class="description" id="panel-description"></span><span id="opacity-value" class="small-copy"></span></div><div class="action-row"><button class="button" data-panel-preset="compact">${icon('arrow')}<span>Горизонтальная · 300 px</span></button><button class="button" data-panel-preset="tall">${icon('marker')}<span>Вертикальная</span></button></div><p class="description">Размер подстраивается под окно игры. Состояние воспроизведения отображается внутри панели.</p>`)}${card('Покрытие навигатора',`${toggle('panelMap','Спутниковая карта ArchiVe под машиной')}${input('panelMapOpacity','Непрозрачность карты, %','Отдельно от подложки и 3D-объектов. Детальные тайлы загружаются через интернет.','75','type="range" min="0" max="100" step="1"')}<p class="small-copy" id="map-opacity-value"></p>`)}${card('Сетка',`<div class="inline-fields">${input('radius','Радиус сетки, м','От 1 до 100','20','type="number" min="1" max="100" step="1"')}${input('cell','Размер клетки, м','От 0,1 до 5','1.25','type="number" min="0.1" max="5" step="0.05"')}</div><p class="description" id="grid-validation" hidden></p>`)}</div>
<div class="settings-tab" data-tab-panel="objects">${card('Правила объектов',`${input('model-search','Поиск модели','Правило применяется ко всем объектам выбранной модели.','','type="search" placeholder="Хеш модели"')}<div class="model-list" id="models"></div>`)}</div>
</div>
<div class="page" data-panel="diagnostics">${heading('Диагностика','')}
${card('История поездок',`<canvas id="trip-map" class="route-map trip-map" aria-label="Карта всех сохранённых поездок"></canvas>
<div class="trip-legend"><span><i></i>Вручную</span><span><i></i>Автопилот</span><small id="trip-loading"></small></div>
<p class="map-attribution">GTA V · Rockstar Games · Satellite: ArchiVe</p>`)}
${card('Отчёты',`<p class="status-message" data-text="message"></p><div class="action-row">${button('report','Сохранить отчёт','report')}${button('flights','Записи сбоев','folder')}${button('folder','Папка данных','folder')}</div>`)}
</div>
`;
const colorSettings=document.createElement('dialog');
colorSettings.className='route-color-settings mini-settings';
colorSettings.setAttribute('aria-labelledby','route-color-title');
const routePalette=[['#ffffff','Белый'],['#78c4ff','Голубой'],['#67dec2','Мятный'],['#ffc46e','Янтарный'],['#ff8e9d','Розовый'],['#baa5ff','Сиреневый']];
colorSettings.innerHTML=`<form method="dialog">
    <div class="route-color-heading"><strong id="route-color-title">Настройки маршрута</strong>
    <button type="button" class="button button-small" id="route-color-cancel" aria-label="Закрыть">${icon('close')}</button></div>
    <p class="description" id="route-color-name"></p>
    <div class="mini-preview route-style-preview">
    <svg viewBox="0 0 320 80" aria-hidden="true"><path d="M16 61h62l38-33h72l34 22h82"/><circle cx="16" cy="61" r="5"/><circle cx="304" cy="50" r="5"/></svg>
    <div class="mini-tags"><span>Линия маршрута</span><span id="route-color-hex"></span></div>
    </div>
    <label class="route-color-field"><span>Цвет маршрута</span><input id="route-color" type="color"></label>
    <div class="mini-presets route-swatches" aria-label="Палитра маршрута">
    ${routePalette.map(([color,name])=>`<button type="button" data-route-swatch="${color}" aria-label="${name}" title="${name}"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6" fill="${color}"/></svg></button>`).join('')}
    </div>
    <label class="route-color-field" id="route-pace-row"><span>Учитывать скорость записи</span><input id="route-pace" type="checkbox" role="switch"></label>
    <p class="description" id="route-pace-note"></p>
    <button class="button" type="submit">${icon('save')}<span>Сохранить</span></button>
</form>`;
document.body.append(colorSettings);
document.getElementById('route-color-cancel').onclick=()=>colorSettings.close();
const routeColorInput=document.getElementById('route-color');
function updateRouteColorPreview(){
    const color=routeColorInput.value;
    colorSettings.querySelector('.route-style-preview').style.color=color;
    document.getElementById('route-color-hex').textContent=color.toUpperCase();
    colorSettings.querySelectorAll('[data-route-swatch]').forEach(button=>{
        button.setAttribute('aria-pressed',String(button.dataset.routeSwatch===color));
    });
}
routeColorInput.addEventListener('input',updateRouteColorPreview);
colorSettings.querySelectorAll('[data-route-swatch]').forEach(button=>{
    button.onclick=()=>{
        routeColorInput.value=button.dataset.routeSwatch;
        updateRouteColorPreview();
    };
});
const paceSwitch=document.getElementById('route-pace');
function updateRoutePaceSettings(){
    const route=state.routes.find(r=>r.id===colorSettings.dataset.route);
    paceSwitch.disabled=!route?.paceAvailable;
    paceSwitch.checked=Boolean(route?.paceEnabled);
    document.getElementById('route-pace-note').textContent=route?.paceAvailable
        ?'Правка секции автоматически отключает этот режим.'
        :'Доступно для маршрутов, записанных начиная с 0.1.42.';
}
paceSwitch.addEventListener('change',()=>{
    if(!paceSwitch.disabled&&!state.recording&&!state.playing)
        send('route|pace|'+colorSettings.dataset.route+'|'+(paceSwitch.checked?'1':'0'));
});
colorSettings.querySelector('form').addEventListener('submit',e=>{
    e.preventDefault();
    if(state.recording||state.playing)return;
    const color=document.getElementById('route-color').value;
    send('route|color|'+colorSettings.dataset.route+'|'+color);
    colorSettings.close();
});
const routeEditor=RouteEditor.create(()=>state,send);
const tripMap=TripMap.create(document.getElementById('trip-map'));
const navCanvas=document.getElementById('navigator-canvas');
const navContext=navCanvas.getContext('2d');
const navPixels=navContext.createImageData(navCanvas.width,navCanvas.height);
function updateNavigatorFrame(encoded){
    document.getElementById('navigator-placeholder').hidden=Boolean(encoded);
    navCanvas.hidden=!encoded;
    if(!encoded)return;
    const bytes=atob(encoded), pixels=navPixels.data;
    let at=0;
    for(let i=0;i+3<bytes.length&&at<pixels.length;i+=4){
        const count=bytes.charCodeAt(i),r=bytes.charCodeAt(i+1),g=bytes.charCodeAt(i+2),b=bytes.charCodeAt(i+3);
        for(let n=0;n<count&&at<pixels.length;++n){pixels[at++]=r;pixels[at++]=g;pixels[at++]=b;pixels[at++]=255;}
    }
    if(at===pixels.length)navContext.putImageData(navPixels,0,0);
}
const sidebarIcons={dashboard:'home',route:'route',settings:'settings',diagnostics:'pulse'};
document.querySelectorAll('[data-page]').forEach(el=>el.insertAdjacentHTML('afterbegin',icon(sidebarIcons[el.dataset.page])));

function navigate(page){if(page!=='settings'&&!state.connected)return;if(!document.querySelector(`[data-panel="${page}"]`))return;currentPage=page;document.querySelectorAll('[data-panel]').forEach(el=>el.classList.toggle('active',el.dataset.panel===page));document.querySelectorAll('[data-page]').forEach(el=>{const active=el.dataset.page===page;el.classList.toggle('active',active);el.setAttribute('aria-current',active?'page':'false');});document.getElementById('content').scrollTop=0;if(page==='route'){renderSavedRoutes();routeEditor.update();drawRoute();}if(page==='settings')renderModels();if(page==='diagnostics')tripMap.draw();send('page:'+page);}
function drawRoute(){if(currentPage==='route')routeEditor.draw();}
function renderModels(){const target=document.getElementById('models');if(target.contains(document.activeElement))return;const filter=document.getElementById('model-search').value.trim().toLowerCase();const models=state.models.filter(m=>m.hash.toLowerCase().includes(filter));const signature=JSON.stringify(models);if(modelSignature===signature)return;modelSignature=signature;target.replaceChildren();if(!models.length){const p=document.createElement('p');p.className='empty-state';p.textContent=filter?'Совпадений нет.':'Объекты появятся после подключения к игре. Сохранённые скрытые модели также останутся в этом списке.';target.append(p);return;}for(const m of models){const row=document.createElement('div');row.className='model-row';const label=document.createElement('div');const title=document.createElement('p');title.className='model-id';title.textContent='Модель '+m.hash;const distance=document.createElement('p');distance.className='description';distance.textContent=m.distance<0?'Сохранённое правило':`${m.distance.toFixed(1)} м от машины`;label.append(title,distance);const select=document.createElement('select');select.setAttribute('aria-label','Правило модели '+m.hash);select.dataset.model=m.id;for(const [value,text] of [[0,'Препятствие'],[1,'Без коллизии'],[2,'Ломаемый'],[3,'Проезжаемый'],[4,'Ожидание']]){const option=document.createElement('option');option.value=value;option.textContent=text;if(value===3)option.disabled=true;select.append(option);}select.value=String(m.rule);row.append(label,select);target.append(row);}}
let routeSignature='';
function renderSavedRoutes(){const target=document.getElementById('saved-routes');if(target.contains(document.activeElement)&&document.activeElement.matches('input'))return;const signature=JSON.stringify([state.routes.map(r=>[r.id,r.name,r.color,r.points,r.paceAvailable,r.paceEnabled]),state.selectedRoute,state.playing,state.recording]);if(signature===routeSignature)return;routeSignature=signature;target.replaceChildren();if(!state.routes.length){const empty=document.createElement('p');empty.className='empty-state';empty.textContent='Сохранённых маршрутов пока нет';target.append(empty);return;}for(const r of state.routes){const row=document.createElement('div');row.className='saved-route'+(state.selectedRoute===r.id?' selected':'');const select=document.createElement('button');select.className='route-select';select.dataset.routeSelect=r.id;select.disabled=state.playing||state.recording;const swatch=document.createElement('span');swatch.className='route-swatch';swatch.style.background=/^#[0-9a-f]{6}$/i.test(r.color)?r.color:'#FFFFFF';const labels=document.createElement('span');const name=document.createElement('span');name.textContent=r.name;const info=document.createElement('span');info.className='description';info.textContent=`${r.points} точек`;labels.append(name,info);select.append(swatch,labels);const rename=document.createElement('input');rename.value=r.name;rename.dataset.routeRename=r.id;rename.maxLength=80;rename.setAttribute('aria-label','Название маршрута '+r.name);rename.disabled=state.playing||state.recording;const remove=document.createElement('button');remove.className='button button-small route-delete';remove.dataset.routeDelete=r.id;remove.disabled=state.playing||state.recording;remove.setAttribute('aria-label','Удалить маршрут '+r.name);remove.innerHTML=icon('trash');const settings=document.createElement('button');settings.type='button';
settings.className='button button-small route-settings';settings.disabled=state.playing||state.recording;
settings.setAttribute('aria-label','Настройки маршрута '+r.name);settings.innerHTML=icon('settings');
settings.onclick=()=>{
    colorSettings.dataset.route=r.id;
    document.getElementById('route-color-name').textContent=r.name;
    document.getElementById('route-color').value=/^#[0-9a-f]{6}$/i.test(r.color)?r.color:'#ffffff';
    updateRoutePaceSettings();
    updateRouteColorPreview();
    colorSettings.showModal();
};
row.append(select,rename,settings,remove);target.append(row);}}
let previousGlyph='', bannerTimeout=0;
const km=new Intl.NumberFormat('ru',{maximumFractionDigits:2});
function setText(el,value){
    value=String(value??'');
    if(el.textContent!==value)el.textContent=value;
}
function update(next){
    if(next.tripPoints){tripMap.append(next.tripPoints,next.tripLoaded,next.tripTotal);return;}
    if(next.mapTileProgress){MapFrame.updateProgress(next.mapTileProgress);return;}
    if(Object.hasOwn(next,'navigatorFrame')){updateNavigatorFrame(next.navigatorFrame);return;}
    const before=state;
    state={...state,...next};
    MapFrame.enable(Boolean(state.mapCache));
    if(colorSettings.open){
        if(state.recording||state.playing)colorSettings.close();
        else updateRoutePaceSettings();
    }
    document.querySelectorAll('[data-text]').forEach(el=>setText(el,state[el.dataset.text]));
    document.querySelectorAll('[data-toggle]').forEach(el=>el.setAttribute('aria-checked',String(Boolean(state[el.dataset.toggle]))));
    for(const id of ['target','radius','cell','panelWidth','panelHeight','panelOpacity','panelMapOpacity','gpsSpeed','gpsWheelStep']){
        const el=document.getElementById(id);
        if(document.activeElement!==el&&el.value!==String(state[id]))el.value=state[id];
    }
    document.querySelectorAll('[data-page]').forEach(el=>{
        el.disabled=el.dataset.page!=='settings'&&!state.connected;
    });
    if(!state.connected&&currentPage!=='settings')navigate('settings');
    else if(state.connected&&!before.connected)navigate('dashboard');
    document.getElementById('sidebar-dot').classList.toggle('online',state.connected);
    setText(document.getElementById('sidebar-connection'),state.connecting?'Подключение…':state.connected?'Игра подключена':'Игра не подключена');
    document.querySelectorAll('[data-command="connect"]').forEach(el=>{
        el.disabled=state.connecting||state.recording||state.playing;
        setText(el.querySelector('span'),state.connecting?'Подключение…':'Подключить');
    });
    setText(document.getElementById('mode'),state.mode);
    setText(document.getElementById('message'),state.message);
    setText(document.getElementById('speed'),state.connected?Math.round(state.speed):'—');
    setText(document.getElementById('navigator-target'),'Цель '+Math.round(state.navigatorTarget||0));
    setText(document.getElementById('odometer'),km.format(state.odometer));
    document.getElementById('dashboard-nav').classList.toggle('with-ground',state.panelMap&&Number(state.panelMapOpacity)>0);
    const glyph=state.error?'error':state.recording?'record':state.playing?'play':'pause';
    if(glyph!==previousGlyph){document.getElementById('navigator-mode-icon').innerHTML=icon(glyph);previousGlyph=glyph;}
    if((state.recording&&!before.recording)||(state.playing&&!before.playing&&!state.error)){
        const banner=document.getElementById('navigator-banner');
        const color=/^#[a-f\d]{6}$/i.test(state.routeColor)?state.routeColor:'#a875ff';
        const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16));
        banner.style.backgroundColor=color;
        banner.style.color=(rgb[0]*.3+rgb[1]*.6+rgb[2]*.1)>145?'#151515':'#fff';
        banner.innerHTML=icon(glyph)+'<strong></strong><small></small>';
        setText(banner.querySelector('strong'),state.recording?'Запись начата':'Воспроизведение');
        setText(banner.querySelector('small'),state.recording?'':state.routeName);
        banner.classList.remove('active');void banner.offsetWidth;banner.classList.add('active');
        clearTimeout(bannerTimeout);bannerTimeout=setTimeout(()=>banner.classList.remove('active'),2300);
    }
    setText(document.getElementById('route-summary'),state.points?state.routeName:'Маршрут ещё не записан');
    setText(document.getElementById('route-count'),state.points?`${state.points} точек`:'Нет маршрута');
    document.getElementById('progress').style.width=state.points?`${Math.min(100,100*state.segment/Math.max(1,state.points-1))}%`:'0%';
    setText(document.getElementById('opacity-value'),state.panelOpacity+'%');
    setText(document.getElementById('map-opacity-value'),state.panelMapOpacity+'%');
    setText(document.getElementById('panel-description'),'Показатели слева, окружение справа');
    document.querySelector('.route-legend span').style.background=state.routeColor;
    if(currentPage==='route'){renderSavedRoutes();routeEditor.update();drawRoute();}
    if(currentPage==='settings')renderModels();
}
document.addEventListener('click',event=>{const removeRoute=event.target.closest('[data-route-delete]');if(removeRoute&&!removeRoute.disabled){send('route|delete|'+removeRoute.dataset.routeDelete);removeRoute.blur();return;}const routeButton=event.target.closest('[data-route-select]');if(routeButton&&!routeButton.disabled){send('route|select|'+routeButton.dataset.routeSelect);routeButton.blur();return;}const preset=event.target.closest('[data-panel-preset]');if(preset){const width=preset.dataset.panelPreset==='compact'?600:360,height=preset.dataset.panelPreset==='compact'?300:480;state.panelWidth=width;state.panelHeight=height;send('value|panelWidth|'+width);send('value|panelHeight|'+height);update({});return;}const link=event.target.closest('[data-page]');if(link){navigate(link.dataset.page);return;}const tab=event.target.closest('[data-tab]');if(tab){document.querySelectorAll('[data-tab]').forEach(el=>{el.classList.toggle('active',el===tab);el.setAttribute('aria-selected',String(el===tab));});document.querySelectorAll('[data-tab-panel]').forEach(el=>el.classList.toggle('active',el.dataset.tabPanel===tab.dataset.tab));return;}const toggleButton=event.target.closest('[data-toggle]');if(toggleButton){const key=toggleButton.dataset.toggle;state[key]=!state[key];send('toggle|'+key+'|'+(state[key]?'1':'0'));update({});return;}const action=event.target.closest('[data-command]');if(action&&!action.disabled){const cmd=action.dataset.command;send(cmd.startsWith('window:')?cmd:'action|'+cmd);}});
document.addEventListener('change',event=>{const el=event.target;if(['gpsSpeed','gpsWheelStep'].includes(el.id)){const value=Number(el.value);const limit=el.id==='gpsSpeed'?[5,300]:[1,30];if(Number.isFinite(value)&&value>=limit[0]&&value<=limit[1]){send('gpsvalue|'+el.id+'|'+value);state[el.id]=value;}return;}if(el.matches('[data-route-rename]')){const name=el.value.trim().replaceAll('|',' ');if(name)send('route|rename|'+el.dataset.routeRename+'|'+name);return;}if(el.matches('select[data-model]')){send('rule|'+el.dataset.model+'|'+el.value);const model=state.models.find(m=>m.id===el.dataset.model);if(model)model.rule=Number(el.value);}else if(['target','radius','cell','panelWidth','panelHeight','panelOpacity','panelMapOpacity','gpsSpeed','gpsWheelStep'].includes(el.id)){const value=el.value.trim().replace(',','.');const numeric=Number(value);const limits={target:[0,Infinity],radius:[1,100],cell:[.1,5],panelWidth:[240,900],panelHeight:[160,800],panelOpacity:[0,100],panelMapOpacity:[0,100]};const [min,max]=limits[el.id];if(!Number.isFinite(numeric)||numeric<min||numeric>max||(el.id==='target'&&numeric<=0)){el.setCustomValidity('Введи допустимое положительное значение');el.reportValidity();return;}el.setCustomValidity('');state[el.id]=value;send('value|'+el.id+'|'+value);update({});}});
document.getElementById('panelOpacity').addEventListener('input',event=>{document.getElementById('opacity-value').textContent=event.target.value+'%';send('value|panelOpacity|'+event.target.value);state.panelOpacity=Number(event.target.value);});
document.getElementById('panelMapOpacity').addEventListener('input',event=>{
    document.getElementById('map-opacity-value').textContent=event.target.value+'%';
});
document.getElementById('model-search').addEventListener('input',()=>{modelSignature='';renderModels();});document.getElementById('collapse').addEventListener('click',()=>{const folded=document.getElementById('sidebar').classList.toggle('collapsed');document.getElementById('collapse').setAttribute('aria-label',folded?'Развернуть панель':'Свернуть панель');setTimeout(drawRoute,310);});
document.getElementById('titlebar').addEventListener('mousedown',event=>{if(event.button===0&&!event.target.closest('button'))send('window:drag');});document.getElementById('titlebar').addEventListener('dblclick',event=>{if(!event.target.closest('button'))send('window:maximize');});document.querySelectorAll('[data-resize]').forEach(el=>el.addEventListener('mousedown',event=>{if(event.button===0)send('window:resize:'+el.dataset.resize);}));window.addEventListener('resize',()=>{drawRoute();if(currentPage==='diagnostics')tripMap.draw();});if(window.chrome?.webview)window.chrome.webview.addEventListener('message',event=>update(event.data));window.District={update,navigate};update({});send('ready');navigate('settings');
})();
