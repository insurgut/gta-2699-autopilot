'use strict';
window.MapFrame=(()=>{
 const frame={left:-4140,right:4860,top:8400,bottom:-5100};
 const fallbackFrame={left:-117.25*48.5,right:(256-117.25)*48.5,top:172.53125*48.5,bottom:(172.53125-256)*48.5};
 const tiles=new Map(), listeners=[];
 const atlas=new Image();
 let enabled=false,redrawPending=false,retryTimer=0;
 let transfers=new Map(),lastCompletion=0;
 const tileKey=(z,x,y)=>(z<<16)|(y<<8)|x;
 function updateProgress({active,finished}){
    const next=new Map(active.map(([key,bytes,total])=>[key,{bytes,total}]));
    const changed=next.size!==transfers.size||[...next].some(([key,{bytes,total}])=>{
        const before=transfers.get(key);
        return !before||before.bytes!==bytes||before.total!==total;
    });
    transfers=next;
    let completed=false;
    for(const [serial,id,missing] of finished){
        if(serial<=lastCompletion)continue;
        lastCompletion=serial;
        const entry=tiles.get(id);
        if(!entry||entry.image)continue;
        if(missing)entry.missing=true;
        else if(entry.retry)entry.retry=1;
        else entry.saved=true;
        completed=true;
    }
    if(changed||completed)redraw();
 }
 const redraw=()=>{
    if(redrawPending)return;
    redrawPending=true;
    requestAnimationFrame(()=>{redrawPending=false;for(const draw of listeners)draw();});
 };
 atlas.onload=redraw;
 atlas.src='map/los-santos.webp';
 function retry(){
    if(!retryTimer)retryTimer=setTimeout(()=>{retryTimer=0;redraw();},6000);
 }
 function tile(z,x,y){
    const key=tileKey(z,x,y);
    let entry=tiles.get(key);
    if(entry){
        tiles.delete(key);
        if(entry.missing||!entry.retry||entry.retry>Date.now()){
            tiles.set(key,entry);
            if(entry.retry&&!entry.missing)retry();
            return entry;
        }
    }
    const revision=entry?`?retry=${Date.now()}`:'';
    entry={image:null,retry:0,missing:false,saved:false};
    tiles.set(key,entry);
    if(tiles.size>480)tiles.delete(tiles.keys().next().value);
    const image=new Image();
    image.onload=()=>{entry.image=image;redraw();};
    image.onerror=()=>{
        if(entry.missing)return;
        if(entry.saved){entry.retry=1;redraw();return;}
        entry.retry=Date.now()+5800;
        window.chrome.webview.postMessage(`maptile|${z}|${x}|${y}`);
        retry();
    };
    image.src=`https://district-map.invalid/${z}/${x}/${y}.webp${revision}`;
    return entry;
 }
 function drawProgress(ctx,key,x,y,size,width,height){
    const barWidth=Math.min(76,size-8);
    if(barWidth<6)return;
    const barHeight=5;
    const bx=x+(size-barWidth)/2,by=y+(size-barHeight)/2;
    if(bx+barWidth<0||bx>width||by+barHeight<0||by>height)return;
    const downloading=transfers.get(key);
    ctx.save();
    ctx.fillStyle='rgba(12,21,32,.82)';
    ctx.fillRect(bx-2,by-2,barWidth+4,barHeight+4);
    ctx.fillStyle=downloading?'#5a7587':'#687884';
    ctx.fillRect(bx,by,barWidth,barHeight);
    if(downloading){
        const {bytes,total}=downloading;
        const fraction=total?Math.min(.99,bytes/total):0;
        const widthFilled=total?barWidth*fraction:barWidth*.28;
        const offset=total?0:(barWidth-widthFilled)*(performance.now()%900)/900;
        if(!total)redraw();
        ctx.fillStyle='#6cdeff';
        ctx.fillRect(bx+offset,by,widthFilled,barHeight);
        if(total&&barWidth>=36&&size>=28){
            ctx.font='bold 10px system-ui';
            ctx.textAlign='center';
            ctx.textBaseline='bottom';
            const label=`${Math.floor(fraction*100)}%`;
            ctx.lineWidth=3;ctx.strokeStyle='#111b26';
            ctx.strokeText(label,bx+barWidth/2,by-3);
            ctx.fillStyle='#f1f9ff';
            ctx.fillText(label,bx+barWidth/2,by-3);
        }
    }
    ctx.restore();
 }
 function detailLevel(view,width,height){
    let target=view.scale>.91?8:view.scale>.23?6:4;
    while(target>4){
        const tilePixels=9000/2**(target-1)*view.scale;
        if((Math.ceil(width/tilePixels)+1)*(Math.ceil(height/tilePixels)+1)<=180)break;
        target-=2;
    }
    return target;
 }
 function restartAt(view,width,height,x,y){
    if(!enabled||x<0||y<0||x>=width||y>=height)return;
    const z=detailLevel(view,width,height),columns=2**(z-1),unit=9000/columns;
    const tileX=Math.floor((view.x+(x-width/2)/view.scale-frame.left)/unit);
    const tileY=Math.floor((frame.top-view.y+(y-height/2)/view.scale)/unit);
    if(tileX<0||tileX>=columns||tileY<0||tileY>=columns*1.5)return;
    const key=tileKey(z,tileX,tileY),entry=tiles.get(key);
    if(!entry||entry.image||entry.missing)return;
    transfers.delete(key);
    entry.saved=false;
    if(entry.retry)entry.retry=Date.now()+5800;
    window.chrome.webview.postMessage(`maptilerestart|${z}|${tileX}|${tileY}`);
    redraw();
 }
 function draw(ctx,view,width,height){
    const sx=x=>width/2+(x-view.x)*view.scale;
    const sy=y=>height/2-(y-view.y)*view.scale;
    const {left,right,top,bottom}=fallbackFrame;
    if(atlas.complete&&atlas.naturalWidth){
        ctx.save();ctx.filter='grayscale(1) brightness(.55)';
        ctx.drawImage(atlas,sx(left),sy(top),(right-left)*view.scale,(top-bottom)*view.scale);
        ctx.restore();
    }
    if(!enabled)return;
    const target=detailLevel(view,width,height);
    const halfWidth=width/(2*view.scale),halfHeight=height/(2*view.scale);
    for(const z of [4,6,8]){
        if(z>target)break;
        const columns=2**(z-1),rows=columns*1.5,unit=9000/columns;
        const firstX=Math.max(0,Math.floor((view.x-halfWidth-frame.left)/unit));
        const lastX=Math.min(columns-1,Math.floor((view.x+halfWidth-frame.left)/unit));
        const firstY=Math.max(0,Math.floor((frame.top-view.y-halfHeight)/unit));
        const lastY=Math.min(rows-1,Math.floor((frame.top-view.y+halfHeight)/unit));
        for(let y=firstY;y<=lastY;++y)for(let x=firstX;x<=lastX;++x){
            const entry=tile(z,x,y);
            const left=sx(frame.left+x*unit),top=sy(frame.top-y*unit),size=unit*view.scale;
            if(entry.image)ctx.drawImage(entry.image,left,top,size,size);
            else if(z===target&&!entry.missing)drawProgress(ctx,tileKey(z,x,y),left,top,size,width,height);
        }
    }
 }
 return {
    bounds:()=>frame,
    observe(draw){listeners.push(draw);},
    updateProgress,
    restartAt,
    enable(value){if(enabled!==value){enabled=value;redraw();}},
    draw,
    constrain(view,width,height){
        const b=frame;
        view.scale=Math.max(view.scale,width/(b.right-b.left),height/(b.top-b.bottom));
        const hx=width/(2*view.scale),hy=height/(2*view.scale);
        view.x=Math.max(b.left+hx,Math.min(b.right-hx,view.x));
        view.y=Math.max(b.bottom+hy,Math.min(b.top-hy,view.y));
        return view;
    }
 };
})();
