'use strict';
window.RouteEditor={create(getState,send){
 const canvas=document.getElementById('route-canvas'),ctx=canvas.getContext('2d');const stage=document.createElement('div');stage.className='map-stage';canvas.before(stage);stage.append(canvas);stage.insertAdjacentHTML('beforeend','<svg class="map-north" viewBox="0 0 24 30" aria-label="Север"><path fill="currentColor" d="M12 2 5 17l7-4 7 4z"/><text x="12" y="28" fill="currentColor" text-anchor="middle" font-size="10">N</text></svg>');const markerLayer=document.createElement('div');markerLayer.className='wait-marker-layer';stage.append(markerLayer);
 const dock=document.createElement('div'), sentinel=document.createElement('div'), spacer=document.createElement('div');
 dock.className='route-map-dock';
 sentinel.className='route-map-sentinel';
 spacer.className='route-map-spacer';
 stage.before(sentinel,dock,spacer);
 dock.append(stage);
 const expand=document.createElement('button');
 expand.type='button';
 expand.className='route-map-expand';
 expand.innerHTML=Components.icon('marker')+'<span>Карта</span>';
 expand.setAttribute('aria-label','Развернуть карту');
 expand.setAttribute('aria-expanded','false');
 stage.append(expand);
 const content=document.getElementById('content');
 let pinned=false, heldOpen=false, dockFrame=0;
 function syncDock(){
    if(!dock.getClientRects().length)return;
    const edge=content.getBoundingClientRect().top+parseFloat(getComputedStyle(dock).top);
    const next=sentinel.getBoundingClientRect().top<edge-1;
    if(next!==pinned){
        pinned=next;heldOpen=false;
        dock.classList.toggle('is-pinned',pinned);
        syncExpansion();
    }
 }
 function syncExpansion(){
    const open=pinned&&(heldOpen);
    dock.classList.toggle('is-open',open);
    expand.setAttribute('aria-expanded',String(open));
    expand.setAttribute('aria-label',open?'Свернуть карту':'Развернуть карту');
 }
 function scheduleDock(){
    if(!dockFrame)dockFrame=requestAnimationFrame(()=>{dockFrame=0;syncDock();});
 }
 content.addEventListener('scroll',scheduleDock,{passive:true});
 expand.addEventListener('pointerdown',e=>e.stopPropagation());
 expand.addEventListener('click',()=>{
    heldOpen=!heldOpen;
    syncExpansion();
 });
 let mapFrame=0;
 new ResizeObserver(()=>{
    scheduleDock();
    if(!mapFrame)mapFrame=requestAnimationFrame(()=>{mapFrame=0;draw();});
 }).observe(stage);
 const $=id=>document.getElementById(id);let view={x:0,y:0,scale:.1},key=null,selection=null,hoverSection=null,drag=null,width=0,height=0,screen=[],pendingFit=true,framedSection=null,framedPath=null,framedWidth=0,framedHeight=0;let popupPoint={x:20,y:40},sectionSignature='',sectionPath=null;const editor=$('section-editor'),popup=document.createElement('div');popup.id='section-popup';popup.className='mini-settings';popup.hidden=true;popup.setAttribute('role','dialog');popup.setAttribute('aria-label','Параметры участка');const close=document.createElement('button');close.className='button button-small popup-close';close.innerHTML=Components.icon('close');close.setAttribute('aria-label','Закрыть редактор участка');close.onclick=()=>popup.hidden=true;popup.append(close,editor);document.body.append(popup);let selectedWait=null,waitSignature='';const waitPopup=document.createElement('div');waitPopup.id='waiting-popup';waitPopup.className='waiting-popup mini-settings';waitPopup.hidden=true;waitPopup.setAttribute('role','dialog');waitPopup.setAttribute('aria-label','Время ожидания объекта');const waitFields=[
  ['stop','Дистанция остановки, м',0.2,30],
  ['inner','Граница ближнего сектора, м',0.2,120],
  ['outer','Граница среднего сектора, м',0.2,120],
  ['near','Ближний сектор, км/ч',1,130],
  ['mid','Средний сектор, км/ч',1,130],
  ['far','Дальний сектор, км/ч',1,130]
 ];
 waitPopup.setAttribute('aria-label','Настройки объекта ожидания');
 waitPopup.innerHTML=`<button class="button button-small popup-close" id="wait-close" aria-label="Закрыть настройки">${Components.icon('close')}</button>
 <div class="mini-heading">${Components.icon('marker')}<div><strong>Объект ожидания</strong><p id="wait-object-label"></p></div></div>
 <div class="mini-preview">
   <svg id="wait-diagram" viewBox="0 0 360 58" aria-hidden="true">
     <path d="M20 33H340" class="mini-track"/>
     <path d="M18 24h12v18H18zM13 27h5m-5 12h5" class="wait-gate"/>
     <line id="wait-near-line" x1="0" x2="0" y1="33" y2="33" class="wait-near"/>
     <line id="wait-mid-line" x1="0" x2="0" y1="33" y2="33" class="wait-mid"/>
     <line id="wait-far-line" x1="0" x2="320" y1="33" y2="33" class="wait-far"/>
     <path d="m326 28-7 5 7 5" class="wait-arrow"/>
     <line id="wait-stop-line" y1="18" y2="48" class="wait-stop"/>
   </svg>
   <div id="wait-summary" class="wait-summary"></div>
 </div>
 <form id="wait-form"><fieldset id="wait-fields">
 <div class="section-fields wait-approach-fields">
 ${waitFields.map(([id,label,min,max])=>`<label>${label}<input type="number" id="wait-${id}" min="${min}" max="${max}" step="any" required></label>`).join('')}
 </div>
 <div class="wait-timing">
   <label>Задержка после начала движения, с<input type="number" id="wait-seconds" min="0" max="3600" step="any" required></label>
   <div class="mini-presets" aria-label="Быстрая установка задержки">
     ${[0,3,5,10].map(seconds=>`<button type="button" data-wait-delay="${seconds}">${seconds} с</button>`).join('')}
   </div>
 </div>
 </fieldset><div class="action-row"><button class="button button-primary" id="wait-save">${Components.icon('save')}Сохранить</button></div>
 <p class="small-copy" id="wait-feedback" role="status"></p></form>`;
 const waitValues=()=>['seconds',...waitFields.map(([id])=>id)].map(id=>$('wait-'+id).valueAsNumber);
 const metric=new Intl.NumberFormat('ru',{maximumFractionDigits:2});
 function drawWaitPreview(){
    const [delay,stop,inner,outer,near,mid,far]=waitValues();
    const valid=[...$('wait-fields').querySelectorAll('input')].every(input=>input.validity.valid)&&stop<inner&&inner<outer;
    const diagram=$('wait-diagram');
    diagram.classList.toggle('is-invalid',!valid);
    const summary=$('wait-summary');
    waitPopup.querySelectorAll('[data-wait-delay]').forEach(button=>{
        button.setAttribute('aria-pressed',String(Number(button.dataset.waitDelay)===delay));
    });
    if(!valid){
        summary.textContent='Укажи дистанции по возрастанию и заполни скорости.';
        return;
    }
    const scale=220/outer;
    const start=40;
    const positions=[stop,inner,outer].map(value=>start+value*scale);
    $('wait-stop-line').setAttribute('x1',positions[0]);
    $('wait-stop-line').setAttribute('x2',positions[0]);
    ['near','mid','far'].forEach((id,index)=>{
        const line=$('wait-'+id+'-line');
        line.setAttribute('x1',positions[index]);
        if(index<2)line.setAttribute('x2',positions[index+1]);
    });
    summary.innerHTML=`<span class="near">Ближний <b>${metric.format(near)} км/ч</b></span>
        <span class="mid">Средний <b>${metric.format(mid)} км/ч</b></span>
        <span class="far">Дальний <b>${metric.format(far)} км/ч</b></span>`;
 }
 document.body.append(waitPopup);
 $('wait-form').addEventListener('input',drawWaitPreview);
 waitPopup.querySelectorAll('[data-wait-delay]').forEach(button=>{
    button.onclick=()=>{
        $('wait-seconds').value=button.dataset.waitDelay;
        drawWaitPreview();
    };
 });
 $('wait-close').onclick=()=>waitPopup.hidden=true;
 $('wait-form').onsubmit=event=>{
    event.preventDefault();
    const state=getState();
    if(!selectedWait||state.playing||state.recording||!state.selectedRoute)return;
    const values=waitValues();
    const [,stop,inner,outer]=values;
    if(!(stop<inner&&inner<outer)){
        $('wait-feedback').textContent='Дистанция остановки должна быть меньше обеих границ. Укажи границы по возрастанию.';
        return;
    }
    send(`waiting|${state.selectedRoute}|${selectedWait[3]}|${values[0]}|${selectedWait[4]}|${values.slice(1).join('|')}`);
    $('wait-feedback').textContent='Сохранение...';
    $('wait-feedback').dataset.pending='1';
 };
 const project=q=>[width/2+(q[0]-view.x)*view.scale,height/2-(q[1]-view.y)*view.scale];
 function fit(city=false){pendingFit=false;framedSection=null;const p=getState().path;if(city||p.length<2){view={x:0,y:-900,scale:Math.min((width||700)/6300,(height||440)/5900)};}else{const xs=p.map(q=>q[0]),ys=p.map(q=>q[1]);let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;for(let i=0;i<xs.length;i++){minX=Math.min(minX,xs[i]);maxX=Math.max(maxX,xs[i]);minY=Math.min(minY,ys[i]);maxY=Math.max(maxY,ys[i]);}view={x:(minX+maxX)/2,y:(minY+maxY)/2,scale:Math.min((width||700)/Math.max(100,maxX-minX+100),(height||440)/Math.max(100,maxY-minY+100),5)};}draw();}
 function frameSection(){
    if(!framedSection)return;
    const p=getState().path;
    if(framedPath===p&&framedWidth===width&&framedHeight===height)return;
    const {from,to}=framedSection;
    if(!p[from]||!p[to+1]){framedSection=null;return;}
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(let i=from;i<=to+1;i++){
        minX=Math.min(minX,p[i][0]);maxX=Math.max(maxX,p[i][0]);
        minY=Math.min(minY,p[i][1]);maxY=Math.max(maxY,p[i][1]);
    }
    const fitWidth=Math.max(1,width-64),fitHeight=Math.max(1,height-34);
    view={x:(minX+maxX)/2,y:(minY+maxY)/2,
          scale:Math.min(fitWidth/Math.max(14,maxX-minX),fitHeight/Math.max(14,maxY-minY),7)};
    framedPath=p;framedWidth=width;framedHeight=height;
 }
 function color(hex,p){if(!(p[2]>0)&&!p[3])return hex;const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255),hi=Math.max(...rgb),lo=Math.min(...rgb),d=hi-lo,s=hi?d/hi:0,v=Math.min(1,Math.max(.4,.55+(p[2]>0?Math.min(p[2],100)/100*.35:.2)+(p[3]?.1:0))),sat=Math.min(1,s*(p[3]?.45:1.1));return '#'+rgb.map(c=>Math.round(255*v*(1-sat+(d>.00001?(c-lo)/d:0)*sat)).toString(16).padStart(2,'0')).join('');}
 function draw(){const box=canvas.getBoundingClientRect();if(!box.width||!box.height)return;const dpr=devicePixelRatio||1;width=box.width;height=box.height;const w=Math.round(width*dpr),h=Math.round(height*dpr);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#262a2d';ctx.fillRect(0,0,width,height);
  if(pendingFit){fit();return;}
  frameSection();
  MapFrame.constrain(view,width,height);
  MapFrame.draw(ctx,view,width,height);
  const state=getState(),p=state.path;screen=p.map(project);ctx.lineCap='round';ctx.lineJoin='round';
  for(let i=0;i+1<p.length;i++){const a=screen[i],b=screen[i+1];if(Math.max(a[0],b[0])<0||Math.min(a[0],b[0])>width||Math.max(a[1],b[1])<0||Math.min(a[1],b[1])>height)continue;const highlight=hoverSection||selection;const selected=highlight&&i>=highlight.from&&i<=highlight.to;ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);if(selected){ctx.strokeStyle='#ffffff';ctx.lineWidth=6;ctx.stroke();}ctx.strokeStyle=color(state.routeColor,p[i+1]);ctx.lineWidth=3;ctx.stroke();}
  drawWaitMarkers();
  if(screen.length){ctx.fillStyle=state.routeColor;ctx.strokeStyle='#111';ctx.lineWidth=2;ctx.beginPath();ctx.arc(...screen[0],5,0,Math.PI*2);ctx.fill();}
  if(state.connected){const car=project(state.position);ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=2;ctx.beginPath();ctx.arc(...car,5,0,Math.PI*2);ctx.fill();ctx.stroke();}
 }
 function nearest(x,y){let best=-1,gap=22;for(let i=0;i+1<screen.length;i++){const a=screen[i],b=screen[i+1],dx=b[0]-a[0],dy=b[1]-a[1],n=dx*dx+dy*dy,t=n?Math.max(0,Math.min(1,((x-a[0])*dx+(y-a[1])*dy)/n)):0,d=Math.hypot(x-a[0]-t*dx,y-a[1]-t*dy);if(d<gap){gap=d;best=i;}}return best;}
 function drawSectionPreview(){
    const path=getState().path;
    const from=$('section-from').valueAsNumber-1;
    const to=$('section-to').valueAsNumber-1;
    const line=$('section-preview-line'),start=$('section-preview-start'),end=$('section-preview-end');
    const valid=Number.isInteger(from)&&Number.isInteger(to)&&from>=0&&to>=from&&to+1<path.length;
    $('section-preview').hidden=!valid;
    if(!valid)return;
    let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,length=0;
    for(let i=from;i<=to+1;i++){
        const [x,y]=path[i];
        minX=Math.min(minX,x);maxX=Math.max(maxX,x);
        minY=Math.min(minY,y);maxY=Math.max(maxY,y);
        if(i>from)length+=Math.hypot(x-path[i-1][0],y-path[i-1][1]);
    }
    const scale=Math.min(318/Math.max(1,maxX-minX),62/Math.max(1,maxY-minY));
    const projectPoint=([x,y])=>[(170+(x-(minX+maxX)/2)*scale).toFixed(1),(42-(y-(minY+maxY)/2)*scale).toFixed(1)];
    const points=[];
    const step=Math.max(1,Math.ceil((to+1-from)/240));
    for(let i=from;i<=to;i+=step)points.push(projectPoint(path[i]));
    points.push(projectPoint(path[to+1]));
    line.setAttribute('points',points.map(point=>point.join(',')).join(' '));
    line.setAttribute('stroke',getState().routeColor);
    for(const [dot,point] of [[start,points[0]],[end,points.at(-1)]]){
        dot.setAttribute('cx',point[0]);dot.setAttribute('cy',point[1]);
    }
    const speed=$('section-speed').valueAsNumber;
    $('section-preview-distance').textContent=`${Math.round(length)} м · ${to-from+1} отр.`;
    $('section-preview-speed').textContent=Number.isFinite(speed)?(speed>0?`${metric.format(speed)} км/ч`:'Общая скорость'):'Разная скорость';
    const obstacles=$('section-obstacles').value;
    $('section-preview-obstacles').textContent=obstacles==='1'?'Препятствия игнорируются':obstacles==='0'?'Препятствия учитываются':'Разные правила препятствий';
 }
 editor.addEventListener('input',drawSectionPreview);
 function showSelection(){const state=getState(),disabled=state.playing||state.recording||!selection||!state.selectedRoute;$('section-editor').disabled=disabled;if(!selection){$('section-title').textContent='Выбери участок маршрута';return;}
  const {from,to}=selection,p=state.path;let length=0;for(let i=from;i<=to;i++)length+=Math.hypot(p[i+1][0]-p[i][0],p[i+1][1]-p[i][1]);$('section-title').textContent=`Отрезки ${from+1}–${to+1} · ${Math.round(length)} м`;
  $('section-from').value=from+1;$('section-to').value=to+1;for(const id of ['section-from','section-to'])$(id).max=p.length-1;
  const values=p.slice(from+1,to+2),first=values[0],sameSpeed=values.every(q=>Math.abs((q[2]||0)-(first[2]||0))<.01),sameIgnore=values.every(q=>Boolean(q[3])===Boolean(first[3]));$('section-speed').value=sameSpeed?Math.round((first[2]||0)*100)/100:'';$('section-obstacles').value=sameIgnore?(first[3]?'1':'0'):'mixed';$('section-feedback').textContent='';
  drawSectionPreview();
 }
 function update(){const state=getState(),next=state.gpsDriving?'gps':state.selectedRoute+'|'+state.path.length;if(key!==next){key=next;selection=null;hoverSection=null;framedSection=null;popup.hidden=true;waitPopup.hidden=true;selectedWait=null;pendingFit=true;showSelection();}else $('section-editor').disabled=state.playing||state.recording||!selection||!state.selectedRoute;
  if($('wait-feedback').dataset.pending==='1'&&(state.message==='Настройки объекта ожидания сохранены.'||state.message?.startsWith('Не удалось'))){$('wait-feedback').textContent=state.message;$('wait-feedback').dataset.pending='0';}
  scheduleDock();renderSections();if(state.playing||state.recording)popup.hidden=true;$('wait-fields').disabled=state.playing||state.recording;$('wait-save').disabled=state.playing||state.recording||!state.selectedRoute;
  if($('section-feedback').dataset.pending==='1'&&state.message?.startsWith('Не удалось')){$('section-feedback').textContent=state.message;$('section-feedback').dataset.pending='0';}
  if(state.message==='Параметры участка сохранены.'){if($('section-feedback').dataset.pending==='1'){showSelection();$('section-feedback').textContent=state.message;$('section-feedback').dataset.pending='0';}}
 }
 function openPopup(){if(!selection||getState().playing||getState().recording)return;popup.hidden=false;popup.style.left=Math.max(8,Math.min(innerWidth-popup.offsetWidth-8,popupPoint.x))+'px';popup.style.top=Math.max(30,Math.min(innerHeight-popup.offsetHeight-8,popupPoint.y))+'px';}
 function renderSections(){
    const state=getState(),p=state.path;
    const sig=JSON.stringify([state.selectedRoute,state.routeColor,state.playing,state.recording]);
    if(sig===sectionSignature&&p===sectionPath)return;
    sectionSignature=sig;sectionPath=p;hoverSection=null;
    const host=$('custom-sections');
    host.replaceChildren();
    for(let i=1;i<p.length;){
        if(!(p[i][2]>0)&&!p[i][3]){++i;continue;}
        let j=i;
        while(j+1<p.length&&Math.abs((p[j+1][2]||0)-(p[i][2]||0))<.01&&Boolean(p[j+1][3])===Boolean(p[i][3]))++j;
        const from=i-1,to=j-1;
        const row=document.createElement('div');row.className='route-section-row';
        const stripe=document.createElement('i');stripe.style.background=color(state.routeColor,p[i]);
        const text=document.createElement('span');
        text.textContent=`Участок ${from+1}–${to+1} · ${p[i][2]>0?Math.round(p[i][2])+' км/ч':'общая скорость'}${p[i][3]?' · игнорировать препятствия':''}`;
        const control=(glyph,label)=>{
            const button=document.createElement('button');button.type='button';
            button.className='button button-small section-icon';
            button.setAttribute('aria-label',label);button.title=label;
            button.disabled=state.playing||state.recording;
            button.innerHTML=Components.icon(glyph);
            return button;
        };
        const remove=control('trash',`Удалить участок ${from+1}–${to+1}`);
        const settings=control('settings',`Настроить участок ${from+1}–${to+1}`);
        remove.onclick=()=>{
            popup.hidden=true;
            send(`section|${state.selectedRoute}|${from}|${to}|0|0|${p.length}`);
        };
        settings.onclick=()=>{
            const box=settings.getBoundingClientRect();
            selection={from,to};showSelection();popupPoint={x:box.right+8,y:box.bottom+8};
            openPopup();draw();
        };
        const highlight=()=>{
            hoverSection={from,to};
            framedSection=hoverSection;
            framedPath=null;
            draw();
        };
        const clear=()=>{hoverSection=null;draw();};
        row.addEventListener('pointerenter',highlight);row.addEventListener('pointerleave',clear);
        row.addEventListener('focusin',highlight);row.addEventListener('focusout',clear);
        row.append(stripe,text,remove,settings);host.append(row);
        i=j+1;
    }
 }
 function placePopup(el,x,y){el.hidden=false;el.style.left=Math.max(8,Math.min(innerWidth-el.offsetWidth-8,x))+'px';el.style.top=Math.max(30,Math.min(innerHeight-el.offsetHeight-8,y))+'px';}
 function drawWaitMarkers(){const state=getState(),markers=state.waitingMarkers||[],sig=JSON.stringify([state.selectedRoute,markers,state.routeColor]);if(sig!==waitSignature){waitSignature=sig;markerLayer.replaceChildren();for(let i=0;i<markers.length;i++){const q=markers[i],button=document.createElement('button');button.type='button';button.className='wait-blip';button.dataset.waitIndex=q[3]??i;button.setAttribute('aria-label',`Ожидание объекта ${i+1}: ${q[2]??5} секунд`);button.title=`Ожидание · ${q[2]??5} с`;button.style.setProperty('--blip-color',state.routeColor);button.addEventListener('pointerdown',e=>{if(e.button===0)e.stopPropagation();});button.onclick=e=>{e.stopPropagation();if(q.length<5)return;selectedWait=q;popup.hidden=true;$('wait-seconds').value=q[2];waitFields.forEach(([id],index)=>$('wait-'+id).value=q[index+5]??'');$('wait-object-label').textContent=`Метка ${i+1} · модель ${q[4]}`;drawWaitPreview();const live=getState();$('wait-fields').disabled=live.playing||live.recording;$('wait-save').disabled=live.playing||live.recording||!live.selectedRoute;$('wait-feedback').textContent=live.playing||live.recording?'Останови проезд или запись, чтобы изменить настройки.':'';$('wait-feedback').dataset.pending='0';placePopup(waitPopup,e.clientX+14,e.clientY+14);};const outline=document.createElement('span'),symbol=document.createElement('span');outline.className='wait-blip-outline';symbol.className='wait-blip-symbol';outline.append(symbol);button.append(outline);markerLayer.append(button);}}for(let i=0;i<markers.length;i++){const pos=project(markers[i]),button=markerLayer.children[i];button.style.left=pos[0]+'px';button.style.top=pos[1]+'px';button.hidden=pos[0]<0||pos[0]>width||pos[1]<0||pos[1]>height;button.disabled=false;}}
 document.addEventListener('keydown',event=>{
    if(event.key!=='Escape')return;
    if(!waitPopup.hidden)waitPopup.hidden=true;
    else if(!popup.hidden)popup.hidden=true;
 });
 document.addEventListener('pointerdown',e=>{if(!popup.contains(e.target)&&e.target!==canvas&&!e.target.closest('.route-section-row'))popup.hidden=true;if(!waitPopup.contains(e.target)&&!e.target.closest('.wait-blip'))waitPopup.hidden=true;});window.addEventListener('resize',()=>{popup.hidden=true;waitPopup.hidden=true;});
 function position(event){const r=canvas.getBoundingClientRect();return [event.clientX-r.left,event.clientY-r.top];}
 stage.addEventListener('pointerdown',e=>{if(e.button!==0&&e.button!==1)return;popup.hidden=true;waitPopup.hidden=true;const [x,y]=position(e),s=getState();const pan=e.button===1||e.shiftKey;if(!pan&&(s.playing||s.recording))return;const edge=nearest(x,y);if(!pan&&edge<0)return;framedSection=null;drag={x,y,cx:view.x,cy:view.y,edge,pan};canvas.setPointerCapture(e.pointerId);if(!pan){selection={from:edge,to:edge};showSelection();draw();}e.preventDefault();});
 stage.addEventListener('pointermove',e=>{if(!drag)return;const [x,y]=position(e);if(drag.pan){view.x=drag.cx-(x-drag.x)/view.scale;view.y=drag.cy+(y-drag.y)/view.scale;}else{const edge=nearest(x,y);if(edge>=0){selection={from:Math.min(edge,drag.edge),to:Math.max(edge,drag.edge)};showSelection();}}draw();});
 stage.addEventListener('pointerup',e=>{if(drag&&!drag.pan){popupPoint={x:e.clientX+14,y:e.clientY+14};openPopup();}drag=null;});canvas.addEventListener('auxclick',e=>{if(e.button===1)e.preventDefault();});stage.addEventListener('pointercancel',()=>{drag=null;});canvas.addEventListener('lostpointercapture',()=>{drag=null;});
 function zoom(f,x=width/2,y=height/2){framedSection=null;const old=view.scale;view.scale=Math.max(.018,Math.min(12,old*f));view.x+=(x-width/2)*(1/old-1/view.scale);view.y-=(y-height/2)*(1/old-1/view.scale);draw();}
 canvas.addEventListener('wheel',e=>{e.preventDefault();const [x,y]=position(e);zoom(Math.exp(-e.deltaY*.0015),x,y);},{passive:false});
 canvas.addEventListener('keydown',e=>{if(e.key==='Home')fit();else if(e.key==='+'||e.key==='=')zoom(1.4);else if(e.key==='-')zoom(1/1.4);else if(e.key.startsWith('Arrow')){framedSection=null;view.x+=(e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0)*60/view.scale;view.y+=(e.key==='ArrowUp'?1:e.key==='ArrowDown'?-1:0)*60/view.scale;draw();}else return;e.preventDefault();});
 for(const id of ['section-from','section-to'])$(id).onchange=()=>{const from=Number($('section-from').value)-1,to=Number($('section-to').value)-1;if(Number.isInteger(from)&&Number.isInteger(to)&&from>=0&&to>=from&&to<getState().path.length-1){selection={from,to};showSelection();draw();}};
 function apply(reset){const s=getState();if(!selection||s.playing||s.recording||!s.selectedRoute)return;if($('section-preview').hidden){$('section-feedback').textContent='Укажи допустимые границы участка.';return;}const raw=$('section-speed').value,kmh=reset?0:Number(raw),ignore=reset?'0':$('section-obstacles').value;if((!reset&&!raw.trim())||!Number.isFinite(kmh)||kmh<0||kmh>3600||!['0','1'].includes(ignore)){$('section-feedback').textContent='Укажи скорость от 0 до 3600 км/ч и правило препятствий.';return;}send(`section|${s.selectedRoute}|${selection.from}|${selection.to}|${kmh}|${ignore}|${s.path.length}`);$('section-feedback').textContent='Сохранение...';$('section-feedback').dataset.pending='1';}
 $('section-apply').onclick=()=>apply(false);$('section-reset').onclick=()=>apply(true);
 MapFrame.observe(draw);
 return {draw,update,project,select(from,to){selection={from,to};showSelection();draw();},get selection(){return selection;},get view(){return view;},color};
}};
