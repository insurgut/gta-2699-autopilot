'use strict';
window.TripMap = {create(canvas) {
    const ctx=canvas.getContext('2d');
    const paths=[new Path2D(),new Path2D()];
    const view={x:0,y:2050,scale:.035};
    let last=null,drag=null,scheduled=false,initial=true;
    const request=()=>{
        if(!scheduled){scheduled=true;requestAnimationFrame(()=>{scheduled=false;draw();});}
    };
    function draw() {
        const {width,height}=canvas.getBoundingClientRect();
        if(!width||!height)return;
        const ratio=Math.min(devicePixelRatio||1,2);
        const w=Math.round(width*ratio),h=Math.round(height*ratio);
        if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
        ctx.setTransform(ratio,0,0,ratio,0,0);
        ctx.fillStyle='#25292d';ctx.fillRect(0,0,width,height);
        if(initial){
            const bounds=MapFrame.bounds();
            view.x=(bounds.left+bounds.right)/2;view.y=(bounds.top+bounds.bottom)/2;
            view.scale=Math.min(width/(bounds.right-bounds.left),height/(bounds.top-bounds.bottom));
            initial=false;
        }
        const px=x=>width/2+(x-view.x)*view.scale;
        const py=y=>height/2-(y-view.y)*view.scale;
        MapFrame.draw(ctx,view,width,height);
        ctx.save();ctx.translate(px(0),py(0));ctx.scale(view.scale,-view.scale);
        ctx.lineJoin='round';ctx.lineCap='round';ctx.lineWidth=2/view.scale;
        ctx.strokeStyle='#c3c6d1';ctx.stroke(paths[0]);
        ctx.strokeStyle='#6eb9ff';ctx.stroke(paths[1]);ctx.restore();
        if(last){
            ctx.beginPath();ctx.arc(px(last[0]),py(last[1]),4,0,Math.PI*2);
            ctx.fillStyle='#fff';ctx.fill();
        }
    }
    function append(rows,loaded,total){
        for(const point of rows){
            const [x,y,flags]=point, index=(flags&2)?1:0;
            const path=paths[index];
            if(last&&!(flags&1)){
                if((last[2]&2)!==(flags&2))path.moveTo(last[0],last[1]);
                path.lineTo(x,y);
            }else path.moveTo(x,y);
            last=point;
        }
        document.getElementById('trip-loading').textContent=loaded<total?`Загружено ${loaded.toLocaleString('ru')} из ${total.toLocaleString('ru')} точек`:'';
        request();
    }
    canvas.addEventListener('pointerdown',e=>{
        if(e.button!==0&&e.button!==1)return;
        drag={x:e.clientX,y:e.clientY,cx:view.x,cy:view.y,button:e.button,moved:false};
        canvas.setPointerCapture(e.pointerId);
        e.preventDefault();
    });
    canvas.addEventListener('pointermove',e=>{
        if(!drag)return;
        if(!drag.moved&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<5)return;
        drag.moved=true;
        view.x=drag.cx-(e.clientX-drag.x)/view.scale;
        view.y=drag.cy+(e.clientY-drag.y)/view.scale;
        request();
    });
    canvas.addEventListener('pointerup',e=>{
        if(drag?.button===0&&!drag.moved&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<5){
            const rect=canvas.getBoundingClientRect();
            MapFrame.restartAt(view,rect.width,rect.height,e.clientX-rect.left,e.clientY-rect.top);
        }
        drag=null;
    });
    for(const event of ['pointercancel','lostpointercapture'])canvas.addEventListener(event,()=>{drag=null;});
    canvas.addEventListener('wheel',e=>{
        e.preventDefault();
        const rect=canvas.getBoundingClientRect(),old=view.scale;
        view.scale=Math.max(.009,Math.min(10,old*Math.exp(-e.deltaY*.0015)));
        view.x+=(e.clientX-rect.left-rect.width/2)*(1/old-1/view.scale);
        view.y-=(e.clientY-rect.top-rect.height/2)*(1/old-1/view.scale);
        request();
    },{passive:false});
    MapFrame.observe(request);
    return {append,draw:request};
}};
