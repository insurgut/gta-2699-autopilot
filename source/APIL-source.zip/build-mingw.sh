#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
cxx=${APIL_CXX:-x86_64-w64-mingw32-g++}
windres=${APIL_WINDRES:-x86_64-w64-mingw32-windres}
mkdir -p bin dist
flags=(-std=c++17 -O2 -Wall -Wextra -Werror -static -s -municode -mwindows -DUNICODE -D_UNICODE)
"$cxx" "${flags[@]}" src/external_reader.cpp -o bin/DistrictTelemetry.exe -luser32
python3 - <<'RESOURCES'
from pathlib import Path
assets = {Path('third_party/webview2/WebView2Loader.dll'): Path('bin/WebView2Loader.dll')}
assets.update((file, file) for file in sorted(Path('ui').rglob('*')) if file.is_file())
assets[Path('LICENSE')] = Path('LICENSE')
with open('bin/web_resources.rc', 'w') as rc, open('bin/web_resources.inc', 'w') as cpp:
    for resource, (source, target) in enumerate(assets.items(), start=110):
        rc.write(f'{resource} RCDATA "{source.as_posix()}"\n')
        cpp.write(f'if(!unpackApilResource(root/L"{target.as_posix()}",{resource}))return false;\n')
RESOURCES
"$windres" src/apil.rc -O coff -o bin/apil-resource.o
"$cxx" "${flags[@]}" -Wno-cast-function-type src/controller.cpp bin/apil-resource.o -o dist/APIL.exe \
  -luser32 -lgdi32 -lshell32 -lole32 -lshlwapi -luuid -lwinhttp -lbcrypt -ladvapi32
python3 - <<'PY'
from hashlib import sha256
from pathlib import Path
import re
root = Path('dist')
binary = (root / 'APIL.exe').read_bytes()
version = re.search(r'apilVersion\[\]="([0-9.]+)"', Path('src/apil_release.hpp').read_text()).group(1)
(root / 'update.txt').write_text(f'{version} {len(binary)} {sha256(binary).hexdigest()}\n', encoding='ascii')
PY
