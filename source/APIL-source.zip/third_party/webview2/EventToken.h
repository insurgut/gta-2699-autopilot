#pragma once
// ABI-compatible definition from the Windows SDK's EventToken contract.
// MinGW-w64 does not ship this header.
typedef struct EventRegistrationToken { __int64 value; } EventRegistrationToken;
