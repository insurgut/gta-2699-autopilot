# ETS2LA UI adaptation

Source: https://github.com/ETS2LA/ETS2LA/tree/v2026.11.5251/ETS2LA.UI
Tag: v2026.11.5251. Original authors: ETS2LA contributors. GPL-3.0.

The upstream MainLayout, Titlebar, Card, SidebarButton, SidebarGroupLabel,
SectionTitle, Switch, Input and Dialog markup/classes and compiled app.css
are adapted in ui/. Framework expressions were replaced with local JavaScript
and the native District bridge. CSS is copied; only the local font URL changes.
Reference Razor sources and input.css are retained here as attribution and design
source. The rendered markup in ui/components.js and index.html is the editable
source used at runtime. Upstream account, update, sponsorship, catalogue, SDK,
networking, help chatbot and telemetry upload features are not included.
This is a modified private District interface, not an official ETS2LA release.

Original District controller sources retain their MIT notices. The distributed
combined adaptation is provided under GPL-3.0, with full source in this archive.
